. "C:\GitHub\Marshell\User Scripts\Export-NavUserPermissionToExcel.ps1"

Export-NavUserPermissionsToExcel -NavVersion 100 `
                                 -NavServerInstanceName 'DynamicsNAV100'